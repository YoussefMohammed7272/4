import { mutation } from "./_generated/server";

// بيانات الأذكار